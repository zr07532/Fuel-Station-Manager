﻿namespace databases_proj
{
    partial class Form12
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LBL_AddProducts = new System.Windows.Forms.Label();
            this.lbl_id = new System.Windows.Forms.Label();
            this.lbl_PName = new System.Windows.Forms.Label();
            this.lbl_SP = new System.Windows.Forms.Label();
            this.lbl_QtySup = new System.Windows.Forms.Label();
            this.lbl_BuyingP = new System.Windows.Forms.Label();
            this.ID_tb = new System.Windows.Forms.TextBox();
            this.Qty_tb = new System.Windows.Forms.TextBox();
            this.SPrice_tb = new System.Windows.Forms.TextBox();
            this.BPrice_tb = new System.Windows.Forms.TextBox();
            this.Name_tb = new System.Windows.Forms.TextBox();
            this.lbl_idInfo = new System.Windows.Forms.Label();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LBL_AddProducts
            // 
            this.LBL_AddProducts.AutoSize = true;
            this.LBL_AddProducts.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_AddProducts.Location = new System.Drawing.Point(322, 48);
            this.LBL_AddProducts.Name = "LBL_AddProducts";
            this.LBL_AddProducts.Size = new System.Drawing.Size(117, 20);
            this.LBL_AddProducts.TabIndex = 0;
            this.LBL_AddProducts.Text = "Add Products";
            // 
            // lbl_id
            // 
            this.lbl_id.AutoSize = true;
            this.lbl_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_id.Location = new System.Drawing.Point(67, 103);
            this.lbl_id.Name = "lbl_id";
            this.lbl_id.Size = new System.Drawing.Size(100, 20);
            this.lbl_id.TabIndex = 1;
            this.lbl_id.Text = "Product ID:";
            // 
            // lbl_PName
            // 
            this.lbl_PName.AutoSize = true;
            this.lbl_PName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PName.Location = new System.Drawing.Point(67, 169);
            this.lbl_PName.Name = "lbl_PName";
            this.lbl_PName.Size = new System.Drawing.Size(127, 20);
            this.lbl_PName.TabIndex = 2;
            this.lbl_PName.Text = "Product Name:";
            // 
            // lbl_SP
            // 
            this.lbl_SP.AutoSize = true;
            this.lbl_SP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SP.Location = new System.Drawing.Point(67, 282);
            this.lbl_SP.Name = "lbl_SP";
            this.lbl_SP.Size = new System.Drawing.Size(108, 20);
            this.lbl_SP.TabIndex = 3;
            this.lbl_SP.Text = "Selling Price";
            // 
            // lbl_QtySup
            // 
            this.lbl_QtySup.AutoSize = true;
            this.lbl_QtySup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_QtySup.Location = new System.Drawing.Point(67, 338);
            this.lbl_QtySup.Name = "lbl_QtySup";
            this.lbl_QtySup.Size = new System.Drawing.Size(156, 20);
            this.lbl_QtySup.TabIndex = 4;
            this.lbl_QtySup.Text = "Quantity Supplied:";
            // 
            // lbl_BuyingP
            // 
            this.lbl_BuyingP.AutoSize = true;
            this.lbl_BuyingP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_BuyingP.Location = new System.Drawing.Point(67, 230);
            this.lbl_BuyingP.Name = "lbl_BuyingP";
            this.lbl_BuyingP.Size = new System.Drawing.Size(113, 20);
            this.lbl_BuyingP.TabIndex = 5;
            this.lbl_BuyingP.Text = "Buying Price:";
            // 
            // ID_tb
            // 
            this.ID_tb.Location = new System.Drawing.Point(304, 102);
            this.ID_tb.Name = "ID_tb";
            this.ID_tb.Size = new System.Drawing.Size(302, 20);
            this.ID_tb.TabIndex = 6;
            // 
            // Qty_tb
            // 
            this.Qty_tb.Location = new System.Drawing.Point(304, 340);
            this.Qty_tb.Name = "Qty_tb";
            this.Qty_tb.Size = new System.Drawing.Size(302, 20);
            this.Qty_tb.TabIndex = 7;
            // 
            // SPrice_tb
            // 
            this.SPrice_tb.Location = new System.Drawing.Point(304, 282);
            this.SPrice_tb.Name = "SPrice_tb";
            this.SPrice_tb.Size = new System.Drawing.Size(302, 20);
            this.SPrice_tb.TabIndex = 8;
            // 
            // BPrice_tb
            // 
            this.BPrice_tb.Location = new System.Drawing.Point(304, 232);
            this.BPrice_tb.Name = "BPrice_tb";
            this.BPrice_tb.Size = new System.Drawing.Size(302, 20);
            this.BPrice_tb.TabIndex = 9;
            // 
            // Name_tb
            // 
            this.Name_tb.Location = new System.Drawing.Point(304, 169);
            this.Name_tb.Name = "Name_tb";
            this.Name_tb.Size = new System.Drawing.Size(302, 20);
            this.Name_tb.TabIndex = 10;
            // 
            // lbl_idInfo
            // 
            this.lbl_idInfo.AutoSize = true;
            this.lbl_idInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_idInfo.Location = new System.Drawing.Point(304, 129);
            this.lbl_idInfo.Name = "lbl_idInfo";
            this.lbl_idInfo.Size = new System.Drawing.Size(300, 9);
            this.lbl_idInfo.TabIndex = 11;
            this.lbl_idInfo.Text = "Please enter the first two letters of your product followed by a 4 digit integer " +
    "to set the ID.";
            // 
            // btn_cancel
            // 
            this.btn_cancel.Location = new System.Drawing.Point(605, 415);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_cancel.TabIndex = 12;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(713, 415);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 13;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // Form12
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.lbl_idInfo);
            this.Controls.Add(this.Name_tb);
            this.Controls.Add(this.BPrice_tb);
            this.Controls.Add(this.SPrice_tb);
            this.Controls.Add(this.Qty_tb);
            this.Controls.Add(this.ID_tb);
            this.Controls.Add(this.lbl_BuyingP);
            this.Controls.Add(this.lbl_QtySup);
            this.Controls.Add(this.lbl_SP);
            this.Controls.Add(this.lbl_PName);
            this.Controls.Add(this.lbl_id);
            this.Controls.Add(this.LBL_AddProducts);
            this.Name = "Form12";
            this.Text = "Form12";
            this.Load += new System.EventHandler(this.Form12_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LBL_AddProducts;
        private System.Windows.Forms.Label lbl_id;
        private System.Windows.Forms.Label lbl_PName;
        private System.Windows.Forms.Label lbl_SP;
        private System.Windows.Forms.Label lbl_QtySup;
        private System.Windows.Forms.Label lbl_BuyingP;
        private System.Windows.Forms.TextBox ID_tb;
        private System.Windows.Forms.TextBox Qty_tb;
        private System.Windows.Forms.TextBox SPrice_tb;
        private System.Windows.Forms.TextBox BPrice_tb;
        private System.Windows.Forms.TextBox Name_tb;
        private System.Windows.Forms.Label lbl_idInfo;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_add;
    }
}