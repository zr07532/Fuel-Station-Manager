﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class Form12 : Form
    {
        const string conString = @"Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlConnection con = new SqlConnection(conString);
        SqlCommand cm = new SqlCommand();
        public Form12()
        {
            InitializeComponent();
        }

        private void Form12_Load(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "insert into Products values (@P_id, @PName, @SP, @qty_P); insert into Supply_Schedule values (@S_id, @P_id, GetDate(), @Bprice, @qty_P)";
            cm = new SqlCommand(sql, con);

            // Specify the value of the parameters
            cm.Parameters.AddWithValue("@P_id", ID_tb.Text);
            cm.Parameters.AddWithValue("@PName", Name_tb.Text);
            cm.Parameters.AddWithValue("@Bprice", BPrice_tb.Text);
            cm.Parameters.AddWithValue("@SP", SPrice_tb.Text);
            cm.Parameters.AddWithValue("@qty_P", float.Parse(Qty_tb.Text));
            cm.Parameters.AddWithValue("@S_ID", invt_form.SetValueForSupplyID);
            try
            {
                cm.ExecuteNonQuery();
                MessageBox.Show("Records Inserted Successfully");
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Error Generated. Details: " + ex.ToString());
            }
            finally
            {
                con.Close();
                MessageBox.Show("Addition Of Product failed");
            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            invt_form fm9 = new invt_form();
            fm9.Show();
        }
    }
    }

