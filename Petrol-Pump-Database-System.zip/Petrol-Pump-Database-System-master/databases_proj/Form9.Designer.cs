﻿namespace databases_proj
{
    partial class invt_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.back_btn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Btn_AddProduct = new System.Windows.Forms.Button();
            this.Btn_UpdateProduct = new System.Windows.Forms.Button();
            this.btn_SupplySc = new System.Windows.Forms.Button();
            this.btn_RemProd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // back_btn
            // 
            this.back_btn.BackColor = System.Drawing.Color.LavenderBlush;
            this.back_btn.Location = new System.Drawing.Point(403, 429);
            this.back_btn.Margin = new System.Windows.Forms.Padding(2);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(100, 32);
            this.back_btn.TabIndex = 10;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LavenderBlush;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(115, 9);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(338, 27);
            this.label3.TabIndex = 11;
            this.label3.Text = "THE EAGLE PETROL STATION";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(21, 167);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(482, 258);
            this.dataGridView1.TabIndex = 20;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Btn_AddProduct
            // 
            this.Btn_AddProduct.Location = new System.Drawing.Point(21, 109);
            this.Btn_AddProduct.Name = "Btn_AddProduct";
            this.Btn_AddProduct.Size = new System.Drawing.Size(236, 23);
            this.Btn_AddProduct.TabIndex = 21;
            this.Btn_AddProduct.Text = "Add Products";
            this.Btn_AddProduct.UseVisualStyleBackColor = true;
            this.Btn_AddProduct.Click += new System.EventHandler(this.Btn_AddProduct_Click);
            // 
            // Btn_UpdateProduct
            // 
            this.Btn_UpdateProduct.Location = new System.Drawing.Point(267, 109);
            this.Btn_UpdateProduct.Name = "Btn_UpdateProduct";
            this.Btn_UpdateProduct.Size = new System.Drawing.Size(236, 23);
            this.Btn_UpdateProduct.TabIndex = 22;
            this.Btn_UpdateProduct.Text = "Update Products";
            this.Btn_UpdateProduct.UseVisualStyleBackColor = true;
            this.Btn_UpdateProduct.Click += new System.EventHandler(this.Btn_UpdateProduct_Click);
            // 
            // btn_SupplySc
            // 
            this.btn_SupplySc.Location = new System.Drawing.Point(21, 138);
            this.btn_SupplySc.Name = "btn_SupplySc";
            this.btn_SupplySc.Size = new System.Drawing.Size(482, 23);
            this.btn_SupplySc.TabIndex = 23;
            this.btn_SupplySc.Text = "Supply History and Update";
            this.btn_SupplySc.UseVisualStyleBackColor = true;
            this.btn_SupplySc.Click += new System.EventHandler(this.btn_SupplySc_Click);
            // 
            // btn_RemProd
            // 
            this.btn_RemProd.Location = new System.Drawing.Point(21, 430);
            this.btn_RemProd.Name = "btn_RemProd";
            this.btn_RemProd.Size = new System.Drawing.Size(236, 23);
            this.btn_RemProd.TabIndex = 24;
            this.btn_RemProd.Text = "Show Removed Products";
            this.btn_RemProd.UseVisualStyleBackColor = true;
            this.btn_RemProd.Click += new System.EventHandler(this.btn_RemProd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(218, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 20);
            this.label1.TabIndex = 25;
            this.label1.Text = "Inventory";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::databases_proj.Properties.Resources.Orange_Modern_The_Eagle_Association_Organization_Logo___4_;
            this.pictureBox1.Location = new System.Drawing.Point(24, -5);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 96);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // invt_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(534, 471);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_RemProd);
            this.Controls.Add(this.btn_SupplySc);
            this.Controls.Add(this.Btn_UpdateProduct);
            this.Controls.Add(this.Btn_AddProduct);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.back_btn);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "invt_form";
            this.Text = "Inventory";
            this.Load += new System.EventHandler(this.invt_form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Btn_AddProduct;
        private System.Windows.Forms.Button Btn_UpdateProduct;
        private System.Windows.Forms.Button btn_SupplySc;
        private System.Windows.Forms.Button btn_RemProd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}