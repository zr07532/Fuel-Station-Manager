﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class Supp_info : Form
    {
        const string conString = @"Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlConnection con = new SqlConnection(conString);
        SqlCommand cm = new SqlCommand();
        public Supp_info()
        {
            InitializeComponent();
        }
        
        private void LoadSuppliers()
        {
            
            SqlConnection con = new SqlConnection(conString);
            string sql = "select * from Suppliers";
            cm = new SqlCommand(sql, con);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataTable d = new DataTable();
            da.Fill(d);
            dataGridView1.DataSource = d;
            con.Close();
        }
        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 fm = new Form3();
            fm.Show();
        }

        private void DeleteSupplier(string SupplierID)
        {
            // TODO: Complete the function DeleteOrder 
            // SQL query to Delete the from the order and order details table
            Console.WriteLine("Delete a record");
            Console.WriteLine("Enter Supplier id: ");
            string sql = "delete from Suppliers where Supplier_ID = @Supplier_ID";
            cm = new SqlCommand(sql, con);
            con.Open();
            // Specify the value of the parameters
            cm.Parameters.AddWithValue("@Supplier_ID", SupplierID);
            cm.ExecuteNonQuery();
            con.Close();
        }

    
            private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
            {

            //if click is on new row or header row
                if (e.RowIndex == dataGridView1.NewRowIndex || e.RowIndex < 0)
                    return;

                //Check if click is on specific column 
                if (e.ColumnIndex == dataGridView1.Columns["dataGridViewDeleteButton"].Index)
                {
                    var data = dataGridView1.Rows[e.RowIndex];
                    MessageBox.Show(data.Cells[0].Value.ToString());


                    DeleteSupplier(data.Cells[0].Value.ToString());



                    dataGridView1.Columns.Remove("dataGridViewDeleteButton");
                    dataGridView1.DataSource = null;

                    LoadSuppliers();

                    var deleteButton = new DataGridViewButtonColumn();
                    deleteButton.Name = "dataGridViewDeleteButton";
                    deleteButton.HeaderText = "Delete";
                    deleteButton.Text = "Delete";
                    deleteButton.UseColumnTextForButtonValue = true;

                    dataGridView1.Columns.Add(deleteButton);

                }
            
            }

        private void AddSupplier_Btn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please Enter The Product Before Adding Its Supplier");
            this.Hide();
            Form10 fm = new Form10();
            fm.Show();
        }

        private void Supp_info_Load(object sender, EventArgs e)
        {
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.RowHeadersVisible = false;
            var deleteButton = new DataGridViewButtonColumn();
            deleteButton.Name = "dataGridViewDeleteButton";
            deleteButton.HeaderText = "Delete";
            deleteButton.Text = "Delete";
            deleteButton.UseColumnTextForButtonValue = true;
            LoadSuppliers();
            dataGridView1.Columns.Add(deleteButton);
        }

        private void UpdateSupplier_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form11 fm11 = new Form11();
            fm11.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
