﻿using databases_proj;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace databases_proj
{
    public partial class Log_form : Form
    {
        private void Log_form_Load(object sender, EventArgs e) { }
        public Log_form()
        {
            InitializeComponent();
        }
        public string conString = "Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlCommand cm = new SqlCommand();

        private void login_btn2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select ID, First_Name, UserName, Acc_Password, Working from Employees where IsAdmin = 1";
            cm = new SqlCommand(sql, con);
            SqlDataAdapter da2 = new SqlDataAdapter(cm);
            DataTable dtEmployees = new DataTable();
            da2.Fill(dtEmployees);
            cm.ExecuteNonQuery();
            int count = dtEmployees.Rows.Count;
            int i = 0;
            foreach (DataRow row in dtEmployees.Rows)
            {
                i++;
                Console.WriteLine(row["UserName"]);
                Console.WriteLine(row["Acc_Password"]);
                if (login_tb.Text == row["UserName"].ToString())
                {
                    if (pass_tb.Text == row["Acc_Password"].ToString())
                    {
                        MessageBox.Show("Welcome " + row["First_Name"].ToString() + "!");
                        con.Close();
                        this.Dispose();
                        Form3 fm3 = new Form3();
                        fm3.Show();

                    }
                    else
                    {
                        MessageBox.Show("Invalid Password!");

                        break;
                    }
                }
                else
                {
                    if (i == count)
                    {
                        MessageBox.Show("Invalid Username!");
                    }
                    
                }
            }
        }
    


    private void button1_Click(object sender, EventArgs e)
    {
        this.Hide();
        main_form fm = new main_form();
        fm.Show();
    }

    private void label3_Click(object sender, EventArgs e) { }

    }
}
    