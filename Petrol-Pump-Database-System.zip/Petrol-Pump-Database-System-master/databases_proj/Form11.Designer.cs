﻿namespace databases_proj
{
    partial class Form11
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LBL_UpdateSupplier = new System.Windows.Forms.Label();
            this.LBL_Name = new System.Windows.Forms.Label();
            this.LBL_CNum = new System.Windows.Forms.Label();
            this.LBL_EAddress = new System.Windows.Forms.Label();
            this.LBL_Product = new System.Windows.Forms.Label();
            this.tb_Email = new System.Windows.Forms.TextBox();
            this.tb_Cnum = new System.Windows.Forms.TextBox();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.Btn_Cancel = new System.Windows.Forms.Button();
            this.btn_Update = new System.Windows.Forms.Button();
            this.CB_Suppliers = new System.Windows.Forms.ComboBox();
            this.CB_PSupplied = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // LBL_UpdateSupplier
            // 
            this.LBL_UpdateSupplier.AutoSize = true;
            this.LBL_UpdateSupplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_UpdateSupplier.Location = new System.Drawing.Point(187, 30);
            this.LBL_UpdateSupplier.Name = "LBL_UpdateSupplier";
            this.LBL_UpdateSupplier.Size = new System.Drawing.Size(148, 20);
            this.LBL_UpdateSupplier.TabIndex = 0;
            this.LBL_UpdateSupplier.Text = "Update Suppliers";
            this.LBL_UpdateSupplier.Click += new System.EventHandler(this.LBL_UpdateSupplier_Click);
            // 
            // LBL_Name
            // 
            this.LBL_Name.AutoSize = true;
            this.LBL_Name.Location = new System.Drawing.Point(32, 146);
            this.LBL_Name.Name = "LBL_Name";
            this.LBL_Name.Size = new System.Drawing.Size(38, 13);
            this.LBL_Name.TabIndex = 2;
            this.LBL_Name.Text = "Name:";
            // 
            // LBL_CNum
            // 
            this.LBL_CNum.AutoSize = true;
            this.LBL_CNum.Location = new System.Drawing.Point(32, 190);
            this.LBL_CNum.Name = "LBL_CNum";
            this.LBL_CNum.Size = new System.Drawing.Size(87, 13);
            this.LBL_CNum.TabIndex = 3;
            this.LBL_CNum.Text = "Contact Number:";
            // 
            // LBL_EAddress
            // 
            this.LBL_EAddress.AutoSize = true;
            this.LBL_EAddress.Location = new System.Drawing.Point(32, 238);
            this.LBL_EAddress.Name = "LBL_EAddress";
            this.LBL_EAddress.Size = new System.Drawing.Size(76, 13);
            this.LBL_EAddress.TabIndex = 4;
            this.LBL_EAddress.Text = "Email Address:";
            // 
            // LBL_Product
            // 
            this.LBL_Product.AutoSize = true;
            this.LBL_Product.Location = new System.Drawing.Point(32, 283);
            this.LBL_Product.Name = "LBL_Product";
            this.LBL_Product.Size = new System.Drawing.Size(88, 13);
            this.LBL_Product.TabIndex = 5;
            this.LBL_Product.Text = "Product Supplied";
            // 
            // tb_Email
            // 
            this.tb_Email.Location = new System.Drawing.Point(191, 231);
            this.tb_Email.Name = "tb_Email";
            this.tb_Email.Size = new System.Drawing.Size(200, 20);
            this.tb_Email.TabIndex = 8;
            // 
            // tb_Cnum
            // 
            this.tb_Cnum.Location = new System.Drawing.Point(191, 183);
            this.tb_Cnum.Name = "tb_Cnum";
            this.tb_Cnum.Size = new System.Drawing.Size(200, 20);
            this.tb_Cnum.TabIndex = 9;
            // 
            // tb_name
            // 
            this.tb_name.Location = new System.Drawing.Point(191, 139);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(200, 20);
            this.tb_name.TabIndex = 10;
            // 
            // Btn_Cancel
            // 
            this.Btn_Cancel.Location = new System.Drawing.Point(304, 366);
            this.Btn_Cancel.Name = "Btn_Cancel";
            this.Btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.Btn_Cancel.TabIndex = 11;
            this.Btn_Cancel.Text = "Cancel";
            this.Btn_Cancel.UseVisualStyleBackColor = true;
            this.Btn_Cancel.Click += new System.EventHandler(this.Btn_Cancel_Click);
            // 
            // btn_Update
            // 
            this.btn_Update.Location = new System.Drawing.Point(405, 366);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(75, 23);
            this.btn_Update.TabIndex = 12;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = true;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // CB_Suppliers
            // 
            this.CB_Suppliers.FormattingEnabled = true;
            this.CB_Suppliers.Location = new System.Drawing.Point(35, 82);
            this.CB_Suppliers.Name = "CB_Suppliers";
            this.CB_Suppliers.Size = new System.Drawing.Size(356, 21);
            this.CB_Suppliers.TabIndex = 13;
            this.CB_Suppliers.Text = "Choose Supplier";
            this.CB_Suppliers.SelectedIndexChanged += new System.EventHandler(this.CB_Suppliers_SelectedIndexChanged);
            this.CB_Suppliers.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CB_Suppliers_MouseClick);
            // 
            // CB_PSupplied
            // 
            this.CB_PSupplied.FormattingEnabled = true;
            this.CB_PSupplied.Location = new System.Drawing.Point(191, 274);
            this.CB_PSupplied.Name = "CB_PSupplied";
            this.CB_PSupplied.Size = new System.Drawing.Size(200, 21);
            this.CB_PSupplied.TabIndex = 14;
            // 
            // Form11
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 450);
            this.Controls.Add(this.CB_PSupplied);
            this.Controls.Add(this.CB_Suppliers);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.Btn_Cancel);
            this.Controls.Add(this.tb_name);
            this.Controls.Add(this.tb_Cnum);
            this.Controls.Add(this.tb_Email);
            this.Controls.Add(this.LBL_Product);
            this.Controls.Add(this.LBL_EAddress);
            this.Controls.Add(this.LBL_CNum);
            this.Controls.Add(this.LBL_Name);
            this.Controls.Add(this.LBL_UpdateSupplier);
            this.Name = "Form11";
            this.Text = "Form11";
            this.Load += new System.EventHandler(this.Form11_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LBL_UpdateSupplier;
        private System.Windows.Forms.Label LBL_Name;
        private System.Windows.Forms.Label LBL_CNum;
        private System.Windows.Forms.Label LBL_EAddress;
        private System.Windows.Forms.Label LBL_Product;
        private System.Windows.Forms.TextBox tb_Email;
        private System.Windows.Forms.TextBox tb_Cnum;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.Button Btn_Cancel;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.ComboBox CB_Suppliers;
        private System.Windows.Forms.ComboBox CB_PSupplied;
    }
}