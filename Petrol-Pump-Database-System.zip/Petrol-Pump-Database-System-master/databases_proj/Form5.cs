﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            LBL_Date.Text = DateTime.Now.ToString("dd/ mm/ yyyy");
            name_tb.Text = main_form.SetValueForName;
            ID_tb.Text = main_form.SetValueForID;
            product_tb.Text = main_form.SetValueForProduct;
            quantity_tb.Text = main_form.SetValueForQty;
            bill_tb.Text = main_form.SetValueForTotalBill;
            pay_method.Text = checkout_form.setPaymentMethod
                ;
        }

        

        private void close_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            main_form fm = new main_form();
            fm.Show();
        }
    }
}
