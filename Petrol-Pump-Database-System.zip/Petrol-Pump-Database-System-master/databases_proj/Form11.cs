﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class Form11 : Form
    {
        const string conString = @"Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlCommand cm = new SqlCommand();
        public Form11()
        {
            InitializeComponent();
        }

        private void LBL_UpdateSupplier_Click(object sender, EventArgs e){}

        private void CB_Suppliers_MouseClick(object sender, MouseEventArgs e)
        {
            //SqlConnection con = new SqlConnection(conString);
            //con.Open();
            //string sql = "select Supplier_Name from Suppliers";
            //cm = new SqlCommand(sql, con);
            //SqlDataAdapter da = new SqlDataAdapter(cm);
            //DataSet ds = new DataSet();
            //da.Fill(ds);
            //cm.ExecuteNonQuery();
            //con.Close();
            //CB_Suppliers.DataSource = ds.Tables[0];
            //CB_Suppliers.DisplayMember = "Supplier_Name";
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select Supplier_ID, Supplier_Name from Suppliers";
            cm = new SqlCommand(sql, con);
            SqlDataAdapter da2 = new SqlDataAdapter(cm);
            DataSet ds2 = new DataSet();
            da2.Fill(ds2);
            cm.ExecuteNonQuery();
            CB_Suppliers.DataSource = ds2.Tables[0];
            CB_Suppliers.DisplayMember = "Supplier_Name";
            CB_Suppliers.ValueMember = "Supplier_ID";
            con.Close();
            //**************************
            
            
        }

        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            Supp_info sp = new Supp_info();
            sp.Show();
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            DataRowView r = (DataRowView)CB_Suppliers.SelectedItem;
            DataRowView s = (DataRowView)CB_PSupplied.SelectedItem;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "update Suppliers set Supplier_Name = @SupName, Contact_Num = @Cnum, Email_Address = @Email, Product_Supplied = @Psup where Supplier_ID = @S_ID";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@S_ID", r.Row.ItemArray.ElementAt(0).ToString());
            cm.Parameters.AddWithValue("@SupName", tb_name.Text);
            cm.Parameters.AddWithValue("@Cnum", tb_Cnum.Text);
            cm.Parameters.AddWithValue("@Email", tb_Email.Text);
            cm.Parameters.AddWithValue("@Psup", s.Row.ItemArray.ElementAt(0).ToString());
            cm.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Employee Record Updated!");
            this.Hide();
            Supp_info sp = new Supp_info();
            sp.Show();
        }

        private void CB_Suppliers_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataRowView r = (DataRowView)CB_Suppliers.SelectedItem;
            
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql1 = "select Product_ID, Product_Name from Products where Product_ID not in (select Product_Supplied from Suppliers) or Product_ID = (select Product_Supplied from Suppliers where Supplier_Name = @Sup_Name)";
            //r.Row.ItemArray.ElementAt(0).ToString()
            cm = new SqlCommand(sql1, con);
            cm.Parameters.AddWithValue("@Sup_Name", r.Row.ItemArray.ElementAt(0).ToString());
            SqlDataAdapter da3 = new SqlDataAdapter(cm);
            DataSet ds3 = new DataSet();
            da3.Fill(ds3);
            cm.ExecuteNonQuery();
            CB_PSupplied.DataSource = ds3.Tables[0];
            CB_PSupplied.DisplayMember = "Product_Name";
            CB_PSupplied.ValueMember = "Product_ID";
            
            tb_name.Text = r.Row.ItemArray.ElementAt(0).ToString();
            //****************
            //DataRowView s = (DataRowView)CB_PSupplied.SelectedItem;
            string sql3 = "select Supplier_Name, Contact_Num, Email_Address from Suppliers where Supplier_ID = @Sup_ID";
            cm = new SqlCommand(sql3, con);
            cm.Parameters.AddWithValue("@Sup_ID", r.Row.ItemArray.ElementAt(0).ToString());
            SqlDataAdapter da4 = new SqlDataAdapter(cm);
            DataTable table = new DataTable();
            da4.Fill(table);
            cm.ExecuteNonQuery();
            tb_name.Text = table.Rows[0][0].ToString();
            tb_Cnum.Text = table.Rows[0][1].ToString();
            tb_Email.Text = table.Rows[0][2].ToString();
            //Console.WriteLine(table.Rows[0][0].ToString());
            //Console.WriteLine(table.Rows[0][1].ToString());
            

            con.Close();


        }
    }
}
