﻿namespace databases_proj
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sales_btn = new System.Windows.Forms.Button();
            this.emp_btn = new System.Windows.Forms.Button();
            this.supply_btn = new System.Windows.Forms.Button();
            this.invt_btn = new System.Windows.Forms.Button();
            this.back_btn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // sales_btn
            // 
            this.sales_btn.BackColor = System.Drawing.Color.LavenderBlush;
            this.sales_btn.Location = new System.Drawing.Point(105, 100);
            this.sales_btn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.sales_btn.Name = "sales_btn";
            this.sales_btn.Size = new System.Drawing.Size(333, 49);
            this.sales_btn.TabIndex = 0;
            this.sales_btn.Text = "Sales ";
            this.sales_btn.UseVisualStyleBackColor = false;
            this.sales_btn.Click += new System.EventHandler(this.sales_btn_Click);
            // 
            // emp_btn
            // 
            this.emp_btn.BackColor = System.Drawing.Color.LavenderBlush;
            this.emp_btn.Location = new System.Drawing.Point(105, 261);
            this.emp_btn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.emp_btn.Name = "emp_btn";
            this.emp_btn.Size = new System.Drawing.Size(333, 49);
            this.emp_btn.TabIndex = 1;
            this.emp_btn.Text = "Employee Info";
            this.emp_btn.UseVisualStyleBackColor = false;
            this.emp_btn.Click += new System.EventHandler(this.emp_btn_Click);
            // 
            // supply_btn
            // 
            this.supply_btn.BackColor = System.Drawing.Color.LavenderBlush;
            this.supply_btn.Location = new System.Drawing.Point(105, 177);
            this.supply_btn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.supply_btn.Name = "supply_btn";
            this.supply_btn.Size = new System.Drawing.Size(333, 49);
            this.supply_btn.TabIndex = 2;
            this.supply_btn.Text = "Supplier Info";
            this.supply_btn.UseVisualStyleBackColor = false;
            this.supply_btn.Click += new System.EventHandler(this.supply_btn_Click);
            // 
            // invt_btn
            // 
            this.invt_btn.BackColor = System.Drawing.Color.LavenderBlush;
            this.invt_btn.Location = new System.Drawing.Point(105, 334);
            this.invt_btn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.invt_btn.Name = "invt_btn";
            this.invt_btn.Size = new System.Drawing.Size(333, 49);
            this.invt_btn.TabIndex = 3;
            this.invt_btn.Text = "Inventory";
            this.invt_btn.UseVisualStyleBackColor = false;
            this.invt_btn.Click += new System.EventHandler(this.invt_btn_Click);
            // 
            // back_btn
            // 
            this.back_btn.BackColor = System.Drawing.Color.LavenderBlush;
            this.back_btn.Location = new System.Drawing.Point(401, 416);
            this.back_btn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(71, 28);
            this.back_btn.TabIndex = 4;
            this.back_btn.Text = "Log Out";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.LavenderBlush;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(118, 22);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(338, 27);
            this.label7.TabIndex = 17;
            this.label7.Text = "THE EAGLE PETROL STATION";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::databases_proj.Properties.Resources.Orange_Modern_The_Eagle_Association_Organization_Logo___4_;
            this.pictureBox1.Location = new System.Drawing.Point(26, -1);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 96);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(534, 471);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.invt_btn);
            this.Controls.Add(this.supply_btn);
            this.Controls.Add(this.emp_btn);
            this.Controls.Add(this.sales_btn);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form3";
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button sales_btn;
        private System.Windows.Forms.Button emp_btn;
        private System.Windows.Forms.Button supply_btn;
        private System.Windows.Forms.Button invt_btn;
        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}