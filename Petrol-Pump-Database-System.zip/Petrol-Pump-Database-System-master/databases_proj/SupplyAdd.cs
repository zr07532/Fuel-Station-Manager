﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class SupplyAdd : Form
    {
        const string conString = @"Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlCommand cm = new SqlCommand();
        public SupplyAdd()
        {
            InitializeComponent();
        }

        private void SupplyAdd_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select Product_ID, Product_Name from Products";
            cm = new SqlCommand(sql, con);
            SqlDataAdapter daP = new SqlDataAdapter(cm);
            DataSet dsEmp = new DataSet();
            daP.Fill(dsEmp);
            cm.ExecuteNonQuery();
            CB_Psupplied.DataSource = dsEmp.Tables[0];
            CB_Psupplied.DisplayMember = "Product_Name";
            CB_Psupplied.ValueMember = "Product_ID";
            con.Close();
        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            DataRowView r = (DataRowView)CB_Psupplied.SelectedItem;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "insert into Supply_Schedule values (@SupID, @ProID, GetDate(), @bprice, @QtySup); update products set Present_Quantity = Present_Quantity + @QtySup where Product_Id = @ProID";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@SupID", SupplyHistory.ID_Supply);
            cm.Parameters.AddWithValue("@ProID", r.Row.ItemArray.ElementAt(0));
            cm.Parameters.AddWithValue("@bprice", float.Parse(tb_BuyPrice.Text));
            cm.Parameters.AddWithValue("@QtySup", float.Parse(tb_QtySup.Text));
            cm.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("New Supply Added");
            this.Hide();
            invt_form i_f = new invt_form();
            i_f.Show();
        }

        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            invt_form i_f = new invt_form();
            i_f.Show();
        }
    }
}
