﻿namespace databases_proj
{
    partial class checkout_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.LBL_Qty = new System.Windows.Forms.Label();
            this.LBL_Product = new System.Windows.Forms.Label();
            this.LBL_Name = new System.Windows.Forms.Label();
            this.LBL_ID = new System.Windows.Forms.Label();
            this.LBL_Date = new System.Windows.Forms.Label();
            this.CurrentDT_LBL = new System.Windows.Forms.Label();
            this.bill_tb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.quantity_tb = new System.Windows.Forms.TextBox();
            this.product_tb = new System.Windows.Forms.TextBox();
            this.name_tb = new System.Windows.Forms.TextBox();
            this.ID_tb = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.CB_Banks = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.CB_TransactionBy = new System.Windows.Forms.ComboBox();
            this.LBL_Transaction = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.card_no = new System.Windows.Forms.TextBox();
            this.card_rb1 = new System.Windows.Forms.RadioButton();
            this.Cash_rb1 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.recpt_btn = new System.Windows.Forms.Button();
            this.back_btn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.groupBox1.Controls.Add(this.LBL_Qty);
            this.groupBox1.Controls.Add(this.LBL_Product);
            this.groupBox1.Controls.Add(this.LBL_Name);
            this.groupBox1.Controls.Add(this.LBL_ID);
            this.groupBox1.Controls.Add(this.CurrentDT_LBL);
            this.groupBox1.Controls.Add(this.bill_tb);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.quantity_tb);
            this.groupBox1.Controls.Add(this.product_tb);
            this.groupBox1.Controls.Add(this.name_tb);
            this.groupBox1.Controls.Add(this.ID_tb);
            this.groupBox1.Location = new System.Drawing.Point(31, 95);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(476, 180);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cart";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // LBL_Qty
            // 
            this.LBL_Qty.AutoSize = true;
            this.LBL_Qty.Location = new System.Drawing.Point(155, 64);
            this.LBL_Qty.Name = "LBL_Qty";
            this.LBL_Qty.Size = new System.Drawing.Size(61, 13);
            this.LBL_Qty.TabIndex = 13;
            this.LBL_Qty.Text = "Quantity (L)";
            // 
            // LBL_Product
            // 
            this.LBL_Product.AutoSize = true;
            this.LBL_Product.Location = new System.Drawing.Point(27, 64);
            this.LBL_Product.Name = "LBL_Product";
            this.LBL_Product.Size = new System.Drawing.Size(44, 13);
            this.LBL_Product.TabIndex = 12;
            this.LBL_Product.Text = "Product";
            // 
            // LBL_Name
            // 
            this.LBL_Name.AutoSize = true;
            this.LBL_Name.Location = new System.Drawing.Point(155, 14);
            this.LBL_Name.Name = "LBL_Name";
            this.LBL_Name.Size = new System.Drawing.Size(35, 13);
            this.LBL_Name.TabIndex = 11;
            this.LBL_Name.Text = "Name";
            // 
            // LBL_ID
            // 
            this.LBL_ID.AutoSize = true;
            this.LBL_ID.Location = new System.Drawing.Point(31, 14);
            this.LBL_ID.Name = "LBL_ID";
            this.LBL_ID.Size = new System.Drawing.Size(18, 13);
            this.LBL_ID.TabIndex = 10;
            this.LBL_ID.Text = "ID";
            // 
            // LBL_Date
            // 
            this.LBL_Date.AutoSize = true;
            this.LBL_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Date.Location = new System.Drawing.Point(188, 63);
            this.LBL_Date.Name = "LBL_Date";
            this.LBL_Date.Size = new System.Drawing.Size(43, 18);
            this.LBL_Date.TabIndex = 9;
            this.LBL_Date.Text = "Date";
            this.LBL_Date.Click += new System.EventHandler(this.LBL_Date_Click);
            // 
            // CurrentDT_LBL
            // 
            this.CurrentDT_LBL.AutoSize = true;
            this.CurrentDT_LBL.Location = new System.Drawing.Point(283, 85);
            this.CurrentDT_LBL.Name = "CurrentDT_LBL";
            this.CurrentDT_LBL.Size = new System.Drawing.Size(0, 13);
            this.CurrentDT_LBL.TabIndex = 8;
            // 
            // bill_tb
            // 
            this.bill_tb.BackColor = System.Drawing.Color.LavenderBlush;
            this.bill_tb.Enabled = false;
            this.bill_tb.Location = new System.Drawing.Point(113, 132);
            this.bill_tb.Margin = new System.Windows.Forms.Padding(2);
            this.bill_tb.Name = "bill_tb";
            this.bill_tb.ReadOnly = true;
            this.bill_tb.Size = new System.Drawing.Size(131, 20);
            this.bill_tb.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Enabled = false;
            this.label1.Location = new System.Drawing.Point(28, 134);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Total Bill / RS.";
            // 
            // quantity_tb
            // 
            this.quantity_tb.BackColor = System.Drawing.Color.LavenderBlush;
            this.quantity_tb.Enabled = false;
            this.quantity_tb.Location = new System.Drawing.Point(155, 79);
            this.quantity_tb.Margin = new System.Windows.Forms.Padding(2);
            this.quantity_tb.Name = "quantity_tb";
            this.quantity_tb.ReadOnly = true;
            this.quantity_tb.Size = new System.Drawing.Size(110, 20);
            this.quantity_tb.TabIndex = 4;
            this.quantity_tb.Text = "QUANTITY ";
            // 
            // product_tb
            // 
            this.product_tb.BackColor = System.Drawing.Color.LavenderBlush;
            this.product_tb.Enabled = false;
            this.product_tb.Location = new System.Drawing.Point(30, 79);
            this.product_tb.Margin = new System.Windows.Forms.Padding(2);
            this.product_tb.Name = "product_tb";
            this.product_tb.ReadOnly = true;
            this.product_tb.Size = new System.Drawing.Size(103, 20);
            this.product_tb.TabIndex = 3;
            this.product_tb.Text = "PRODUCT";
            // 
            // name_tb
            // 
            this.name_tb.BackColor = System.Drawing.Color.LavenderBlush;
            this.name_tb.Enabled = false;
            this.name_tb.Location = new System.Drawing.Point(155, 32);
            this.name_tb.Margin = new System.Windows.Forms.Padding(2);
            this.name_tb.Name = "name_tb";
            this.name_tb.ReadOnly = true;
            this.name_tb.Size = new System.Drawing.Size(110, 20);
            this.name_tb.TabIndex = 2;
            this.name_tb.Text = "NAME";
            // 
            // ID_tb
            // 
            this.ID_tb.BackColor = System.Drawing.Color.LavenderBlush;
            this.ID_tb.Enabled = false;
            this.ID_tb.Location = new System.Drawing.Point(30, 32);
            this.ID_tb.Margin = new System.Windows.Forms.Padding(2);
            this.ID_tb.Name = "ID_tb";
            this.ID_tb.ReadOnly = true;
            this.ID_tb.Size = new System.Drawing.Size(103, 20);
            this.ID_tb.TabIndex = 1;
            this.ID_tb.Text = "ID";
            this.ID_tb.TextChanged += new System.EventHandler(this.ID_tb_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.groupBox2.Controls.Add(this.CB_Banks);
            this.groupBox2.Controls.Add(this.dateTimePicker1);
            this.groupBox2.Controls.Add(this.CB_TransactionBy);
            this.groupBox2.Controls.Add(this.LBL_Transaction);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.card_no);
            this.groupBox2.Controls.Add(this.card_rb1);
            this.groupBox2.Controls.Add(this.Cash_rb1);
            this.groupBox2.Location = new System.Drawing.Point(31, 282);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(476, 142);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Payment Method";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // CB_Banks
            // 
            this.CB_Banks.FormattingEnabled = true;
            this.CB_Banks.Items.AddRange(new object[] {
            "Bank Al Habib",
            "Habib Metro Bank",
            "Bank Al Falah",
            "Summit Bank",
            "Standard Chartered",
            "Meezan Bank",
            "Faysal Bank"});
            this.CB_Banks.Location = new System.Drawing.Point(30, 119);
            this.CB_Banks.Name = "CB_Banks";
            this.CB_Banks.Size = new System.Drawing.Size(415, 21);
            this.CB_Banks.TabIndex = 12;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(245, 82);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 11;
            // 
            // CB_TransactionBy
            // 
            this.CB_TransactionBy.FormattingEnabled = true;
            this.CB_TransactionBy.Location = new System.Drawing.Point(237, 24);
            this.CB_TransactionBy.Name = "CB_TransactionBy";
            this.CB_TransactionBy.Size = new System.Drawing.Size(121, 21);
            this.CB_TransactionBy.TabIndex = 10;
            this.CB_TransactionBy.SelectedIndexChanged += new System.EventHandler(this.CB_TransactionBy_SelectedIndexChanged);
            // 
            // LBL_Transaction
            // 
            this.LBL_Transaction.AutoSize = true;
            this.LBL_Transaction.Location = new System.Drawing.Point(150, 25);
            this.LBL_Transaction.Name = "LBL_Transaction";
            this.LBL_Transaction.Size = new System.Drawing.Size(81, 13);
            this.LBL_Transaction.TabIndex = 9;
            this.LBL_Transaction.Text = "Transaction By:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 103);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Bank name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(242, 66);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Card exp date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 67);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Card no.";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // card_no
            // 
            this.card_no.BackColor = System.Drawing.Color.LavenderBlush;
            this.card_no.Enabled = false;
            this.card_no.Location = new System.Drawing.Point(30, 82);
            this.card_no.Margin = new System.Windows.Forms.Padding(2);
            this.card_no.MaxLength = 19;
            this.card_no.Name = "card_no";
            this.card_no.Size = new System.Drawing.Size(201, 20);
            this.card_no.TabIndex = 3;
            // 
            // card_rb1
            // 
            this.card_rb1.AutoSize = true;
            this.card_rb1.Location = new System.Drawing.Point(30, 48);
            this.card_rb1.Margin = new System.Windows.Forms.Padding(2);
            this.card_rb1.Name = "card_rb1";
            this.card_rb1.Size = new System.Drawing.Size(47, 17);
            this.card_rb1.TabIndex = 1;
            this.card_rb1.TabStop = true;
            this.card_rb1.Text = "Card";
            this.card_rb1.UseVisualStyleBackColor = true;
            this.card_rb1.CheckedChanged += new System.EventHandler(this.card_rb1_CheckedChanged);
            // 
            // Cash_rb1
            // 
            this.Cash_rb1.AutoSize = true;
            this.Cash_rb1.Location = new System.Drawing.Point(30, 25);
            this.Cash_rb1.Margin = new System.Windows.Forms.Padding(2);
            this.Cash_rb1.Name = "Cash_rb1";
            this.Cash_rb1.Size = new System.Drawing.Size(49, 17);
            this.Cash_rb1.TabIndex = 0;
            this.Cash_rb1.TabStop = true;
            this.Cash_rb1.Text = "Cash";
            this.Cash_rb1.UseVisualStyleBackColor = true;
            this.Cash_rb1.CheckedChanged += new System.EventHandler(this.Cash_rb1_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LavenderBlush;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(119, 21);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(338, 27);
            this.label3.TabIndex = 7;
            this.label3.Text = "THE EAGLE PETROL STATION";
            // 
            // recpt_btn
            // 
            this.recpt_btn.BackColor = System.Drawing.Color.LavenderBlush;
            this.recpt_btn.Location = new System.Drawing.Point(406, 429);
            this.recpt_btn.Margin = new System.Windows.Forms.Padding(2);
            this.recpt_btn.Name = "recpt_btn";
            this.recpt_btn.Size = new System.Drawing.Size(100, 32);
            this.recpt_btn.TabIndex = 8;
            this.recpt_btn.Text = "Make Payment";
            this.recpt_btn.UseVisualStyleBackColor = false;
            this.recpt_btn.Click += new System.EventHandler(this.recpt_btn_Click);
            // 
            // back_btn
            // 
            this.back_btn.BackColor = System.Drawing.Color.LavenderBlush;
            this.back_btn.Location = new System.Drawing.Point(304, 429);
            this.back_btn.Margin = new System.Windows.Forms.Padding(2);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(100, 32);
            this.back_btn.TabIndex = 9;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::databases_proj.Properties.Resources.Orange_Modern_The_Eagle_Association_Organization_Logo___4_;
            this.pictureBox1.Location = new System.Drawing.Point(31, -6);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 96);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // checkout_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(534, 471);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.recpt_btn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.LBL_Date);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "checkout_form";
            this.Text = "Check Out";
            this.Load += new System.EventHandler(this.checkout_form_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox quantity_tb;
        private System.Windows.Forms.TextBox product_tb;
        private System.Windows.Forms.TextBox name_tb;
        private System.Windows.Forms.TextBox ID_tb;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox bill_tb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton card_rb1;
        private System.Windows.Forms.RadioButton Cash_rb1;
        private System.Windows.Forms.Label label3;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button recpt_btn;
        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox card_no;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label CurrentDT_LBL;
        public System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label LBL_Date;
        private System.Windows.Forms.Label LBL_Qty;
        private System.Windows.Forms.Label LBL_Product;
        private System.Windows.Forms.Label LBL_Name;
        private System.Windows.Forms.Label LBL_ID;
        private System.Windows.Forms.ComboBox CB_TransactionBy;
        private System.Windows.Forms.Label LBL_Transaction;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox CB_Banks;
    }
}