﻿namespace databases_proj
{
    partial class Form10
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LBL_UpdateSupplier = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_SupID = new System.Windows.Forms.TextBox();
            this.tb_Email = new System.Windows.Forms.TextBox();
            this.tb_CNum = new System.Windows.Forms.TextBox();
            this.tb_SupName = new System.Windows.Forms.TextBox();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.CB_ProductSupplied = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_AddP = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LBL_UpdateSupplier
            // 
            this.LBL_UpdateSupplier.AutoSize = true;
            this.LBL_UpdateSupplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_UpdateSupplier.Location = new System.Drawing.Point(192, 36);
            this.LBL_UpdateSupplier.Name = "LBL_UpdateSupplier";
            this.LBL_UpdateSupplier.Size = new System.Drawing.Size(112, 20);
            this.LBL_UpdateSupplier.TabIndex = 0;
            this.LBL_UpdateSupplier.Text = "Add Supplier";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 310);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Product Supplied";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 256);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Email Address";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(37, 202);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Contact Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(37, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Supplier Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(37, 103);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "Supplier ID";
            // 
            // tb_SupID
            // 
            this.tb_SupID.Location = new System.Drawing.Point(247, 102);
            this.tb_SupID.Name = "tb_SupID";
            this.tb_SupID.Size = new System.Drawing.Size(206, 20);
            this.tb_SupID.TabIndex = 6;
            // 
            // tb_Email
            // 
            this.tb_Email.Location = new System.Drawing.Point(247, 258);
            this.tb_Email.Name = "tb_Email";
            this.tb_Email.Size = new System.Drawing.Size(206, 20);
            this.tb_Email.TabIndex = 8;
            // 
            // tb_CNum
            // 
            this.tb_CNum.Location = new System.Drawing.Point(247, 204);
            this.tb_CNum.Name = "tb_CNum";
            this.tb_CNum.Size = new System.Drawing.Size(206, 20);
            this.tb_CNum.TabIndex = 9;
            // 
            // tb_SupName
            // 
            this.tb_SupName.Location = new System.Drawing.Point(247, 152);
            this.tb_SupName.Name = "tb_SupName";
            this.tb_SupName.Size = new System.Drawing.Size(206, 20);
            this.tb_SupName.TabIndex = 10;
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Location = new System.Drawing.Point(251, 374);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(98, 28);
            this.btn_Cancel.TabIndex = 11;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // CB_ProductSupplied
            // 
            this.CB_ProductSupplied.FormattingEnabled = true;
            this.CB_ProductSupplied.Location = new System.Drawing.Point(247, 308);
            this.CB_ProductSupplied.Name = "CB_ProductSupplied";
            this.CB_ProductSupplied.Size = new System.Drawing.Size(206, 21);
            this.CB_ProductSupplied.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(357, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "*Three digit integer";
            // 
            // btn_AddP
            // 
            this.btn_AddP.Location = new System.Drawing.Point(355, 374);
            this.btn_AddP.Name = "btn_AddP";
            this.btn_AddP.Size = new System.Drawing.Size(98, 28);
            this.btn_AddP.TabIndex = 15;
            this.btn_AddP.Text = "Add";
            this.btn_AddP.UseVisualStyleBackColor = true;
            this.btn_AddP.Click += new System.EventHandler(this.btn_AddP_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.LavenderBlush;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(75, 9);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(338, 27);
            this.label7.TabIndex = 17;
            this.label7.Text = "THE EAGLE PETROL STATION";
            // 
            // Form10
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(499, 450);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btn_AddP);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.CB_ProductSupplied);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.tb_SupName);
            this.Controls.Add(this.tb_CNum);
            this.Controls.Add(this.tb_Email);
            this.Controls.Add(this.tb_SupID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LBL_UpdateSupplier);
            this.Name = "Form10";
            this.Text = "AddSupplier";
            this.Load += new System.EventHandler(this.Form10_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LBL_UpdateSupplier;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_SupID;
        private System.Windows.Forms.TextBox tb_Email;
        private System.Windows.Forms.TextBox tb_CNum;
        private System.Windows.Forms.TextBox tb_SupName;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.ComboBox CB_ProductSupplied;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_AddP;
        private System.Windows.Forms.Label label7;
    }
}