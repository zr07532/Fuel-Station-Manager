﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Log_form fm = new Log_form();
            fm.Show();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void sales_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            sales_form sl = new sales_form();
            sl.Show();
        }

        private void supply_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Supp_info sp = new Supp_info();
            sp.Show();
        }

        private void emp_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            emp_form ef = new emp_form();
            ef.Show();
        }

        private void invt_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            invt_form i_f = new invt_form();
            i_f.Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
