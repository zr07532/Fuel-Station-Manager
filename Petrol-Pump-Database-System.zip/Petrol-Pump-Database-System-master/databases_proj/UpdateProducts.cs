﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class UpdateProduct : Form
    {
        public UpdateProduct()
        {
            InitializeComponent();
        }
        public string conString = "Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlCommand cm = new SqlCommand();
        private void UpdateProduct_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select Product_Name from Products";
            cm = new SqlCommand(sql, con);
            SqlDataAdapter dad = new SqlDataAdapter(cm);
            DataSet ds1 = new DataSet();
            dad.Fill(ds1);
            cm.ExecuteNonQuery();
            con.Close();
            CB_ProductID.DataSource = ds1.Tables[0];
            CB_ProductID.DisplayMember = "Product_Name";
            CB_ProductID.ValueMember = "Product_Name";
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            DataRowView r = (DataRowView)CB_ProductID.SelectedItem;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "update Products set Product_Name = @P_name, Selling_Price = @SP where Product_Name = @PnameOrig ";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@P_name", tb_pName.Text);
            cm.Parameters.AddWithValue("@SP", float.Parse(tb_SP.Text));
            cm.Parameters.AddWithValue("@PnameOrig", r.Row.ItemArray.ElementAt(0).ToString());
            cm.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Product Updated!");
            this.Hide();
            invt_form i_f = new invt_form();
            i_f.Show();
        }

        private void CB_ProductID_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataRowView r = (DataRowView)CB_ProductID.SelectedItem;
            //Console.WriteLine(r.Row.ItemArray.ElementAt(0).ToString());
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select Selling_Price from Products where Product_Name = @P_name";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@P_name", r.Row.ItemArray.ElementAt(0).ToString());
            string sellP = cm.ExecuteScalar().ToString();
            
            con.Close();
            tb_pName.Text = r.Row.ItemArray.ElementAt(0).ToString();
            tb_SP.Text = sellP;
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            invt_form i_f = new invt_form();
            i_f.Show();
        }
    }
}
