﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class sales_form : Form
    {
        public sales_form()
        {
            InitializeComponent();
        }
        public string conString = "Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlCommand cm = new SqlCommand();

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 fm = new Form3();
            fm.Show();
        }

        private void sales_form_Load(object sender, EventArgs e)
        {
            //SqlConnection con = new SqlConnection(conString);
            //con.Open();
            //string sql = "select * from Customer_Product";
            //cm = new SqlCommand(sql, con);
            //SqlDataAdapter daP = new SqlDataAdapter(cm);
            //DataSet dsP = new DataSet();
            //daP.Fill(dsP);
            //cm.ExecuteNonQuery();
            //CBProducts.DataSource = dsP.Tables[0];
            //CBProducts.DisplayMember = "Product_Name";
            //CBProducts.ValueMember = "Product_Name";
            //con.Close();
            LoadSales();
        }

        private void dt_from_Click(object sender, EventArgs e)
        {

        }

        private void LB_TotalProfit_Click(object sender, EventArgs e)
        {

        }
        private void LoadSales()
        {
            // TODO: Complete the function LoadOrders
            // SQL Query to Select all records from orders table in the descending order of order date
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select * from Customer_Product";
            cm = new SqlCommand(sql, con);
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataTable d = new DataTable();
            da.Fill(d);
            dataGridView1.DataSource = d;
            string sql2 = "select sum(Total_Bill) as Sales, sum(Profit) as Profit from Customer_Product";
            cm = new SqlCommand(sql2, con);
            SqlDataAdapter daS = new SqlDataAdapter(cm);
            DataTable dtS = new DataTable();
            daS.Fill(dtS);
            //Tb_TotalSales.Text = dtS.Columns[0]
            foreach (DataRow row in dtS.Rows)
            {
                Tb_TotalSales.Text = double.Parse(row["Sales"].ToString()).ToString();
                TB_TotalProfit.Text = row["Profit"].ToString();
                break;
            }
            con.Close();
        }

        private void Btn_Sales_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select * from Customer_Product where Transaction_Date between @from and @to";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@from", dt_from.Value);
            cm.Parameters.AddWithValue("@to", dt_to.Value);
            SqlDataAdapter da3 = new SqlDataAdapter(cm);
            DataTable dt3 = new DataTable();
            da3.Fill(dt3);
            string sql4 = "select sum(Total_Bill) as Sales, sum(Profit) as Profit from Customer_Product where Transaction_Date between @from and @to";
            cm = new SqlCommand(sql4, con);
            cm.Parameters.AddWithValue("@from", dt_from.Value);
            cm.Parameters.AddWithValue("@to", dt_to.Value);
            SqlDataAdapter daS2 = new SqlDataAdapter(cm);
            DataTable dtS2 = new DataTable();
            daS2.Fill(dtS2);
            //Tb_TotalSales.Text = dtS.Columns[0]
            foreach (DataRow row in dtS2.Rows)
            {
                Tb_TotalSales.Text = double.Parse(row["Sales"].ToString()).ToString();
                TB_TotalProfit.Text = row["Profit"].ToString();
                break;
            }
            con.Close();
            dataGridView1.DataSource = dt3;
        }
    }
}
