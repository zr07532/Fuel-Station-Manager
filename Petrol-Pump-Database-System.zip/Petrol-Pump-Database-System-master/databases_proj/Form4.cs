﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class checkout_form : Form
    {
        public checkout_form()
        {
            InitializeComponent();
        }
        public string conString = "Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlCommand cm = new SqlCommand();
        
        private void checkout_form_Load(object sender, EventArgs e)
        {
            LBL_Date.Text = DateTime.Now.ToString();
            name_tb.Text =  main_form.SetValueForName;
            quantity_tb.Text = main_form.SetValueForQty;
            product_tb.Text =  main_form.SetValueForProduct;
            ID_tb.Text=main_form.SetValueForID;
            bill_tb.Text = main_form.SetValueForTotalBill;
            //************************
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select First_Name from Employees where working = 1";
            cm = new SqlCommand(sql, con);
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cm.ExecuteNonQuery();
            con.Close();
            CB_TransactionBy.DataSource = ds.Tables[0];
            CB_TransactionBy.DisplayMember = "First_Name";
            CB_TransactionBy.ValueMember = "First_Name";

        }

        public static string setPaymentMethod = "";

        public static string BoothID = "";
        private void recpt_btn_Click(object sender, EventArgs e)
        {
            Console.WriteLine(CB_TransactionBy.SelectedItem);
            DataRowView r = (DataRowView)CB_TransactionBy.SelectedItem;
            Console.WriteLine(r.Row.ItemArray.ElementAt(0).ToString());

            //if (product_tb.Text == "Petrol")
            //{
            //    Random rnd = new Random();
            //    int booth = rnd.Next(3, 5);
            //    BoothID = "B000" + booth.ToString();
            //}
            //else if (product_tb.Text == "Hi-Octane")
            //{
            //    Random rnd = new Random();
            //    int booth = rnd.Next(1, 3);
            //    BoothID = "B000" + booth.ToString();
            //}
            //else if (product_tb.Text == "Diesel")
            //{
                Random rnd = new Random();
                int booth = rnd.Next(1, 7);
                BoothID = "B000" + booth.ToString();
            //}
            if (Cash_rb1.Checked)
            {
                setPaymentMethod = "Cash";
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                string sql = "insert into Customer_Product  values (@T_ID, @Cname, (select Product_ID from Products where Product_Name = @P_ID), @B_ID, @QtyB, @TotalB, GetDate(), 'Cash', NULL, (select ID from Employees where First_Name = @Trans_B), @TProfit); update Products set Present_Quantity = Present_Quantity - @QtyB where Product_Name = @P_ID";
                //(select ID from Employees where First_Name = @Trans_B)
                //(Transaction_ID,Customer_Name, Product_ID, Booth_ID, Quantity_Bought, Total_Bill, Transaction_Date, Payment_Method, Transaction_By)
                cm = new SqlCommand(sql, con);
                // Specify the value of the parameters
                cm.Parameters.AddWithValue("@T_ID", int.Parse(ID_tb.Text));
                cm.Parameters.AddWithValue("@CName", name_tb.Text);
                cm.Parameters.AddWithValue("@P_ID", product_tb.Text);
                cm.Parameters.AddWithValue("@B_ID", BoothID);
                cm.Parameters.AddWithValue("@QtyB", float.Parse(quantity_tb.Text));
                cm.Parameters.AddWithValue("@TotalB", float.Parse(bill_tb.Text));
                cm.Parameters.AddWithValue("@Trans_B", r.Row.ItemArray.ElementAt(0).ToString());
                cm.Parameters.AddWithValue("@TProfit", float.Parse(main_form.SetValueForProfit));
                cm.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Thank You! Please Come Again!");
                //try
                //{
                //    //cm.ExecuteNonQuery();
                //    //Console.WriteLine("Records Inserted Successfully");
                //}
                //catch (SqlException ex)
                //{
                //    Console.WriteLine("Error Generated. Details: " + ex.ToString());
                //}
                //finally
                //{
                //    con.Close();
                //    Console.WriteLine("Successfully Done!");
                //}
            }
            else if (card_rb1.Checked)
            {
                setPaymentMethod = "Card";
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                string sql = "insert into Customer_Product  values (@T_ID, @Cname, (select Product_ID from Products where Product_Name = @P_ID), @B_ID, @QtyB, @TotalB, GetDate(), 'Card', @CardNum, (select ID from Employees where First_Name = @Trans_B), @TProfit)";
                //(Transaction_ID,Customer_Name, Product_ID, Booth_ID, Quantity_Bought, Total_Bill, Transaction_Date, Payment_Method, Transaction_By)
                cm = new SqlCommand(sql, con);
                // Specify the value of the parameters
                cm.Parameters.AddWithValue("@T_ID", int.Parse(ID_tb.Text));
                cm.Parameters.AddWithValue("@CName", name_tb.Text);
                cm.Parameters.AddWithValue("@P_ID", product_tb.Text);
                cm.Parameters.AddWithValue("@B_ID", BoothID);
                cm.Parameters.AddWithValue("@QtyB", float.Parse(quantity_tb.Text));
                cm.Parameters.AddWithValue("@TotalB", float.Parse(bill_tb.Text));
                cm.Parameters.AddWithValue("@Trans_B", r.Row.ItemArray.ElementAt(0).ToString());
                cm.Parameters.AddWithValue("@CardNum", card_no.Text);
                cm.Parameters.AddWithValue("@TProfit", float.Parse(main_form.SetValueForProfit));
                cm.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Thank You! Please Come Again!");
                //try
                //{
                //    cm.ExecuteNonQuery();
                //    MessageBox.Show("Thank You! Please Come Again!");
                //}
                //catch (SqlException ex)
                //{
                //    Console.WriteLine("Error Generated. Details: " + ex.ToString());
                //}
                //finally
                //{
                //    con.Close();
                //}
            }

            this.Hide();
            Form5 fm5 = new Form5();
            fm5.Show();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            main_form fm = new main_form();
            fm.Show();
        }

        private void groupBox1_Enter(object sender, EventArgs e){}

        private void card_rb1_CheckedChanged(object sender, EventArgs e)
        {
            card_no.Enabled = true;
            dateTimePicker1.Enabled = true;
            CB_Banks.Enabled = true;
        }

        

        private void ID_tb_TextChanged(object sender, EventArgs e){}

        private void LBL_Date_Click(object sender, EventArgs e)
        {
            
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void CB_TransactionBy_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Cash_rb1_CheckedChanged(object sender, EventArgs e)
        {
            card_no.Enabled = false;
            CB_Banks.Enabled=false;
            dateTimePicker1.Enabled = false;
        }
    }
}
