﻿namespace databases_proj
{
    partial class sales_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.back_btn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.dt_from = new System.Windows.Forms.DateTimePicker();
            this.LB_from = new System.Windows.Forms.Label();
            this.LB_To = new System.Windows.Forms.Label();
            this.dt_to = new System.Windows.Forms.DateTimePicker();
            this.LB_TotalSales = new System.Windows.Forms.Label();
            this.Tb_TotalSales = new System.Windows.Forms.TextBox();
            this.LB_TotalProfit = new System.Windows.Forms.Label();
            this.TB_TotalProfit = new System.Windows.Forms.TextBox();
            this.Btn_Sales = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LavenderBlush;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(119, 21);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(338, 27);
            this.label3.TabIndex = 7;
            this.label3.Text = "THE EAGLE PETROL STATION";
            // 
            // back_btn
            // 
            this.back_btn.BackColor = System.Drawing.Color.LavenderBlush;
            this.back_btn.Location = new System.Drawing.Point(425, 429);
            this.back_btn.Margin = new System.Windows.Forms.Padding(2);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(100, 32);
            this.back_btn.TabIndex = 10;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::databases_proj.Properties.Resources.Orange_Modern_The_Eagle_Association_Organization_Logo___4_;
            this.pictureBox1.Location = new System.Drawing.Point(21, -2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 96);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(21, 162);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(482, 233);
            this.dataGridView1.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LavenderBlush;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(250, 58);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 19);
            this.label1.TabIndex = 20;
            this.label1.Text = "Sales";
            // 
            // dt_from
            // 
            this.dt_from.Location = new System.Drawing.Point(21, 112);
            this.dt_from.Name = "dt_from";
            this.dt_from.Size = new System.Drawing.Size(170, 20);
            this.dt_from.TabIndex = 21;
            // 
            // LB_from
            // 
            this.LB_from.AutoSize = true;
            this.LB_from.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_from.Location = new System.Drawing.Point(18, 96);
            this.LB_from.Name = "LB_from";
            this.LB_from.Size = new System.Drawing.Size(41, 16);
            this.LB_from.TabIndex = 22;
            this.LB_from.Text = "From:";
            this.LB_from.Click += new System.EventHandler(this.dt_from_Click);
            // 
            // LB_To
            // 
            this.LB_To.AutoSize = true;
            this.LB_To.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_To.Location = new System.Drawing.Point(197, 96);
            this.LB_To.Name = "LB_To";
            this.LB_To.Size = new System.Drawing.Size(27, 16);
            this.LB_To.TabIndex = 23;
            this.LB_To.Text = "To:";
            // 
            // dt_to
            // 
            this.dt_to.Location = new System.Drawing.Point(197, 112);
            this.dt_to.Name = "dt_to";
            this.dt_to.Size = new System.Drawing.Size(170, 20);
            this.dt_to.TabIndex = 24;
            this.dt_to.ValueChanged += new System.EventHandler(this.dt_from_Click);
            // 
            // LB_TotalSales
            // 
            this.LB_TotalSales.AutoSize = true;
            this.LB_TotalSales.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_TotalSales.Location = new System.Drawing.Point(18, 138);
            this.LB_TotalSales.Name = "LB_TotalSales";
            this.LB_TotalSales.Size = new System.Drawing.Size(71, 15);
            this.LB_TotalSales.TabIndex = 25;
            this.LB_TotalSales.Text = "Total Sales:";
            // 
            // Tb_TotalSales
            // 
            this.Tb_TotalSales.Location = new System.Drawing.Point(91, 137);
            this.Tb_TotalSales.Name = "Tb_TotalSales";
            this.Tb_TotalSales.Size = new System.Drawing.Size(100, 20);
            this.Tb_TotalSales.TabIndex = 26;
            // 
            // LB_TotalProfit
            // 
            this.LB_TotalProfit.AutoSize = true;
            this.LB_TotalProfit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_TotalProfit.Location = new System.Drawing.Point(194, 138);
            this.LB_TotalProfit.Name = "LB_TotalProfit";
            this.LB_TotalProfit.Size = new System.Drawing.Size(68, 15);
            this.LB_TotalProfit.TabIndex = 27;
            this.LB_TotalProfit.Text = "Total Profit:";
            this.LB_TotalProfit.Click += new System.EventHandler(this.LB_TotalProfit_Click);
            // 
            // TB_TotalProfit
            // 
            this.TB_TotalProfit.Location = new System.Drawing.Point(267, 137);
            this.TB_TotalProfit.Name = "TB_TotalProfit";
            this.TB_TotalProfit.Size = new System.Drawing.Size(100, 20);
            this.TB_TotalProfit.TabIndex = 28;
            // 
            // Btn_Sales
            // 
            this.Btn_Sales.Location = new System.Drawing.Point(382, 113);
            this.Btn_Sales.Name = "Btn_Sales";
            this.Btn_Sales.Size = new System.Drawing.Size(121, 44);
            this.Btn_Sales.TabIndex = 29;
            this.Btn_Sales.Text = "View Period Sales";
            this.Btn_Sales.UseVisualStyleBackColor = true;
            this.Btn_Sales.Click += new System.EventHandler(this.Btn_Sales_Click);
            // 
            // sales_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(534, 471);
            this.Controls.Add(this.Btn_Sales);
            this.Controls.Add(this.TB_TotalProfit);
            this.Controls.Add(this.LB_TotalProfit);
            this.Controls.Add(this.Tb_TotalSales);
            this.Controls.Add(this.LB_TotalSales);
            this.Controls.Add(this.dt_to);
            this.Controls.Add(this.LB_To);
            this.Controls.Add(this.LB_from);
            this.Controls.Add(this.dt_from);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.label3);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "sales_form";
            this.Text = "Sales";
            this.Load += new System.EventHandler(this.sales_form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dt_from;
        private System.Windows.Forms.Label LB_from;
        private System.Windows.Forms.Label LB_To;
        private System.Windows.Forms.DateTimePicker dt_to;
        private System.Windows.Forms.Label LB_TotalSales;
        private System.Windows.Forms.TextBox Tb_TotalSales;
        private System.Windows.Forms.Label LB_TotalProfit;
        private System.Windows.Forms.TextBox TB_TotalProfit;
        private System.Windows.Forms.Button Btn_Sales;
    }
}