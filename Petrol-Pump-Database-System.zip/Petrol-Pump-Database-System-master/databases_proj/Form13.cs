﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }
        public string conString = "Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlCommand cm = new SqlCommand();
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            emp_form ef = new emp_form();
            ef.Show();
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            int Admin;
            if (Cbox_Admin.Checked) Admin = 1;
            else Admin = 0;
            
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "insert into Employees values (@EmpID,@EFname,@ELname,GetDate(),@Esalary,@Email,@Cnum,@Admin,@Uname,@Pass, 1)";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@EmpID", SetValueForID);
            cm.Parameters.AddWithValue("@EFname", tb_Fname.Text);
            cm.Parameters.AddWithValue("@ELname", tb_Lname.Text);
            cm.Parameters.AddWithValue("@ESalary", float.Parse(tb_Salary.Text));
            cm.Parameters.AddWithValue("@Email", tb_Email.Text);
            cm.Parameters.AddWithValue("@Cnum", tb_Cnum.Text);
            cm.Parameters.AddWithValue("@Admin", Admin);
            cm.Parameters.AddWithValue("@Uname", tb_UserName.Text);
            cm.Parameters.AddWithValue("@Pass", tb_Password.Text);
            cm.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Employee Added!");
            this.Hide();
            emp_form ef = new emp_form();
            ef.Show();
        }
        public static int SetValueForID;
        private void Form13_Load(object sender, EventArgs e)
        {
            
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select top 1 ID from Employees order by Hire_Date Desc";
            cm = new SqlCommand(sql, con);
            string sID = cm.ExecuteScalar().ToString();
            SetValueForID = int.Parse(sID) + 1;
        }


        private void Cbox_Admin_CheckedChanged(object sender, EventArgs e)
        {
            if (Cbox_Admin.Checked)
            {
                tb_UserName.Enabled = true;
                tb_Password.Enabled = true;
            }
            else
            {
                tb_UserName.Enabled = false;
                tb_Password.Enabled = false;

            }
        }
    }
}
