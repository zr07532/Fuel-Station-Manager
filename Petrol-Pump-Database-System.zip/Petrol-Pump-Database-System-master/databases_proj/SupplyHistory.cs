﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class SupplyHistory : Form
    {
        public SupplyHistory()
        {
            InitializeComponent();
        }

        public string conString = "Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlCommand cm = new SqlCommand();
        private void SupplyHistory_Load(object sender, EventArgs e)
        {
            LoadSchedule();
        }

        private void LoadSchedule()
        {
            // TODO: Complete the function LoadOrders
            // SQL Query to Select all records from orders table in the descending order of order date
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select * from Supply_Schedule";
            cm = new SqlCommand(sql, con);
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataTable d = new DataTable();
            da.Fill(d);
            dataGridView1.DataSource = d;
            con.Close();
        }
        public static int ID_Supply;
        private void btn_NewSupply_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select top 1 Supply_ID from Supply_schedule order by Supply_Date Desc";
            cm = new SqlCommand(sql, con);
            string ID = cm.ExecuteScalar().ToString();
            //if (String.IsNullOrEmpty(Qty))
            //    throw new SqlException();
            int sID = int.Parse(ID) + 1;
            //SetValueForID = ID_tb.Text;
            ID_Supply = sID;
            con.Close();
            this.Hide();
            SupplyAdd SA = new SupplyAdd();
            SA.Show();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Hide();
            invt_form i_f = new invt_form();
            i_f.Show();
        }
    }

}
