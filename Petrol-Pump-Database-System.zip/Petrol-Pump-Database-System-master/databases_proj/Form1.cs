﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections.Specialized;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.Common;

namespace databases_proj
{
    public partial class main_form : Form
    {

        public main_form()
        {
            InitializeComponent();
        }
        public string conString = "Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlCommand cm = new SqlCommand();

        private void main_form_Load(object sender, EventArgs e)
        {
            LBL_Date.Text = DateTime.Now.ToString();
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select Product_Name from Products where Present_Quantity > 0";
            cm = new SqlCommand(sql, con);
            SqlDataAdapter daP = new SqlDataAdapter(cm);
            DataSet dsP = new DataSet();
            daP.Fill(dsP);
            cm.ExecuteNonQuery();
            CBProducts.DataSource = dsP.Tables[0];
            CBProducts.DisplayMember = "Product_Name";
            CBProducts.ValueMember = "Product_Name";
            con.Close();
        }

        private void login_btn1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Log_form fm = new Log_form();
            fm.Show();
            
        }
        public static string SetValueForID = "";
        public static string SetValueForName = "";
        public static string SetValueForProduct = "";
        public static string SetValueForQty= "";
        public static string SetValueForTotalBill = "";
        public static string SetValueForProfit = "";

        private void chk_btn_Click(object sender, EventArgs e)
        {
            DataRowView r = (DataRowView)CBProducts.SelectedItem;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select Present_Quantity from Products where Product_ID = (select Product_ID from Products where Product_Name = @Product_Name)";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@Product_Name", r.Row.ItemArray.ElementAt(0).ToString());
            string Qty = cm.ExecuteScalar().ToString();
            //if (String.IsNullOrEmpty(Qty))
            //    throw new SqlException();
            decimal fQty = decimal.Parse(Qty);
            Console.WriteLine(Qty);
            //SetValueForID = ID_tb.Text;
            SetValueForName = name_tb.Text;
            SetValueForProduct = r.Row.ItemArray.ElementAt(0).ToString();
            SetValueForQty = QtyLb.Value.ToString();

            //*****************Set ID for Transaction
            string sql1 = "select top 1 Transaction_ID from Customer_Product order by Transaction_Date DESC";
            cm = new SqlCommand(sql1, con);
            string sID = cm.ExecuteScalar().ToString();
            int ID = int.Parse(sID) + 1;
            SetValueForID = "000" + ID.ToString();
            //*****************Calculate Total Bill
            string sql2 = "select Selling_Price from Products where Product_Name = @PName";
            cm = new SqlCommand(sql2, con);
            cm.Parameters.AddWithValue("@PName", r.Row.ItemArray.ElementAt(0).ToString());
            string Sprice = cm.ExecuteScalar().ToString();
            decimal price = decimal.Parse(Sprice);
            decimal Payment = price * decimal.Parse(QtyLb.Text);
            SetValueForTotalBill = Payment.ToString();
            //******************Calculate Profit
            string sql3 = "select Top 1 Buying_Price from Supply_Schedule where Product_ID = (select Product_ID from Products where Product_Name = @P_Name) order by Supply_Date DESC";
            cm = new SqlCommand(sql3, con);
            cm.Parameters.AddWithValue("@P_Name", r.Row.ItemArray.ElementAt(0).ToString());
            string BPrice = cm.ExecuteScalar().ToString();
            decimal Buyingprice = decimal.Parse(BPrice);
            decimal Profit = Payment - (Buyingprice * decimal.Parse(QtyLb.Text));
            SetValueForProfit = Profit.ToString();
            //*****************Proceed to next form
            if (String.IsNullOrEmpty(name_tb.Text) || CBProducts.SelectedItem == null || String.IsNullOrEmpty(QtyLb.Text))
            {
                MessageBox.Show("Please Enter All Details To Proceed.");
            }
            else if (con.State == System.Data.ConnectionState.Open && fQty > QtyLb.Value) // 
            {
                this.Hide();
                con.Close();
                checkout_form fm2 = new checkout_form();
                fm2.Show();
            }
            
        }
        
        private void LBL_Date_Click(object sender, EventArgs e){}

        private void QtyLb_ValueChanged(object sender, EventArgs e){}
        private void CBProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataRowView r = (DataRowView)CBProducts.SelectedItem;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql2 = "select Selling_Price from Products where Product_Name = @PName";
            cm = new SqlCommand(sql2, con);
            cm.Parameters.AddWithValue("@PName", r.Row.ItemArray.ElementAt(0).ToString());
            
            string price = cm.ExecuteScalar().ToString();
            con.Close();
            price_tb.Text = price;
        }

        private void price_tb_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
