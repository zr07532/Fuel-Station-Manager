﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class UpdateEmp : Form
    {
        const string conString = @"Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlCommand cm = new SqlCommand();
        public UpdateEmp()
        {
            InitializeComponent();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void UpdateEmp_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select ID, First_Name from Employees where Working = 1";
            cm = new SqlCommand(sql, con);
            SqlDataAdapter daEmp = new SqlDataAdapter(cm);
            DataSet dsEmp = new DataSet();
            daEmp.Fill(dsEmp);
            cm.ExecuteNonQuery();
            CB_Emp.DataSource = dsEmp.Tables[0];
            CB_Emp.DisplayMember = "First_Name";
            CB_Emp.ValueMember = "ID";
            con.Close();
        }

        private void CB_Emp_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataRowView r = (DataRowView)CB_Emp.SelectedItem;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql1 = "select First_Name, Last_Name, Salary, Email_Address, Contact_Number, IsAdmin, UserName, Acc_Password from Employees where ID = @E_id";
            //r.Row.ItemArray.ElementAt(0).ToString()
            cm = new SqlCommand(sql1, con);
            cm.Parameters.AddWithValue("@E_id", r.Row.ItemArray.ElementAt(0));
            SqlDataAdapter da3 = new SqlDataAdapter(cm);
            DataTable ds5 = new DataTable("EmpTable");
            da3.Fill(ds5);
            cm.ExecuteNonQuery();
            tb_fname.Text = ds5.Rows[0][0].ToString();
            tb_lname.Text = ds5.Rows[0][1].ToString();
            tb_salary.Text = ds5.Rows[0][2].ToString();
            tb_Email.Text = ds5.Rows[0][3].ToString();
            tb_Cnum.Text = ds5.Rows[0][4].ToString();
            if (ds5.Rows[0][5].Equals(1)) {CB_Admin.Checked = true;}
            else { CB_Admin.Checked = false;}
            tb_Uname.Text = ds5.Rows[0][6].ToString();
            tb_Password.Text = ds5.Rows[0][7].ToString();
            con.Close();
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            int Admin;
            if (CB_Admin.Checked) { Admin = 1; }
            else { Admin = 0; }
            DataRowView r = (DataRowView)CB_Emp.SelectedItem;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "update Employees set First_Name = @Fname, Last_Name = @Lname, Salary = @Sal, Email_Address = @Email, Contact_Number = @Cnum, IsAdmin = @Admin, UserName = @Uname, Acc_Password = @Pass, Working = 1 where ID = @E_id";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@E_id", r.Row.ItemArray.ElementAt(0));
            cm.Parameters.AddWithValue("@Fname", tb_fname.Text);
            cm.Parameters.AddWithValue("@Lname", tb_lname.Text);
            cm.Parameters.AddWithValue("@Sal", int.Parse(tb_salary.Text));
            cm.Parameters.AddWithValue("@Email", tb_Email.Text);
            cm.Parameters.AddWithValue("@Cnum", tb_Cnum.Text);
            cm.Parameters.AddWithValue("@Admin", Admin);
            cm.Parameters.AddWithValue("@Uname", tb_Uname.Text);
            cm.Parameters.AddWithValue("@Pass", tb_Password.Text);
            cm.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Employee Record Updated!");
            this.Hide();
            emp_form ef = new emp_form();
            ef.Show();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            emp_form ef = new emp_form();
            ef.Show();
        }
    }
}
