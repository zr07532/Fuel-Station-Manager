﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }
        public string conString = "Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlCommand cm = new SqlCommand();

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            Supp_info sp = new Supp_info();
            sp.Show();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "select Product_ID, Product_Name from Products where Product_ID not in (select Product_Supplied from Suppliers)";
            cm = new SqlCommand(sql, con);
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cm.ExecuteNonQuery();
            con.Close();
            CB_ProductSupplied.DataSource = ds.Tables[0];
            CB_ProductSupplied.DisplayMember = "Product_Name";
            CB_ProductSupplied.ValueMember = "Product_ID";
            
        }

        private void btn_AddP_Click(object sender, EventArgs e)
        {
            DataRowView r = (DataRowView)CB_ProductSupplied.SelectedItem;
            string sID = "SU" + tb_SupID.Text;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "insert into Suppliers values (@Sup_id, @SName, @CNum, @email, @PSup)";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@Sup_id", sID);
            cm.Parameters.AddWithValue("@SName", tb_SupName.Text);
            cm.Parameters.AddWithValue("@CNum", tb_CNum.Text);
            cm.Parameters.AddWithValue("@email", tb_Email.Text);
            cm.Parameters.AddWithValue("@PSup", r.Row.ItemArray.ElementAt(0).ToString());
            cm.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Supplier Added!");
            this.Hide();
            Supp_info sp = new Supp_info();
            sp.Show();
        }
    }
}
