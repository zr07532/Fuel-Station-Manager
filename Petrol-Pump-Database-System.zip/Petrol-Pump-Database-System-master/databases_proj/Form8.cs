﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace databases_proj
{
    public partial class emp_form : Form
    {
        const string conString = @"Data Source=HP-15;Initial Catalog=Petrol_Pump;Integrated Security=True";
        SqlConnection con = new SqlConnection(conString);
        SqlCommand cm = new SqlCommand();
        public emp_form()
        {
            InitializeComponent();
        }

        private void LoadEmployees()
        {

            SqlConnection con = new SqlConnection(conString);
            string sql = "select * from Employees where working = 1";
            cm = new SqlCommand(sql, con);
            con.Open();
            SqlDataAdapter daE = new SqlDataAdapter(cm);
            DataTable dtE = new DataTable();
            daE.Fill(dtE);
            dataGridView1.DataSource = dtE;
            con.Close();
        }

            private void back_btn_Click(object sender, EventArgs e)
            {
            this.Hide();
            Form3 fm = new Form3();
            fm.Show();
            }

        private void DeleteEmployee(string EmployeeID)
        {
            // TODO: Complete the function DeleteOrder 
            // SQL query to Delete the from the order and order details table
            Console.WriteLine("Delete a record");
            Console.WriteLine("Enter Employee id: ");
            string sql = "update Employees set Working = 0 where ID = @Emp_ID";
            cm = new SqlCommand(sql, con);
            con.Open();
            // Specify the value of the parameters
            Console.WriteLine(EmployeeID);
            cm.Parameters.AddWithValue("@Emp_ID", int.Parse(EmployeeID));
            cm.ExecuteNonQuery();
            con.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            //if click is on new row or header row
            if (e.RowIndex == dataGridView1.NewRowIndex || e.RowIndex < 0)
                return;

            //Check if click is on specific column 
            if (e.ColumnIndex == dataGridView1.Columns["dataGridViewDeleteButton"].Index)
            {
                var data = dataGridView1.Rows[e.RowIndex];
                MessageBox.Show(data.Cells[0].Value.ToString());

                Console.WriteLine(data.Cells[0].Value.ToString());

                DeleteEmployee(data.Cells[0].Value.ToString());


                dataGridView1.Columns.Remove("dataGridViewDeleteButton");
                dataGridView1.DataSource = null;

                LoadEmployees();

                var deleteButton = new DataGridViewButtonColumn();
                deleteButton.Name = "dataGridViewDeleteButton";
                deleteButton.HeaderText = "Delete";
                deleteButton.Text = "Delete";
                deleteButton.UseColumnTextForButtonValue = true;

                dataGridView1.Columns.Add(deleteButton);

            }

        }

        private void emp_form_Load(object sender, EventArgs e)
        {
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.RowHeadersVisible = false;
            var deleteButton = new DataGridViewButtonColumn();
            deleteButton.Name = "dataGridViewDeleteButton";
            deleteButton.HeaderText = "Delete";
            deleteButton.Text = "Delete";
            deleteButton.UseColumnTextForButtonValue = true;
            LoadEmployees();
            dataGridView1.Columns.Add(deleteButton);
        }

        private void btn_AddEmp_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form13 fm13 = new Form13();
            fm13.Show();
        }

        private void btn_UpdateEmp_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpdateEmp UE = new UpdateEmp();
            UE.Show();
        }
        private void LoadFiredEmployee()
        {
            string sql = "select * from Employees where working = 0";
            cm = new SqlCommand(sql, con);
            con.Open();
            SqlDataAdapter daEf = new SqlDataAdapter(cm);
            DataTable dtEf = new DataTable();
            daEf.Fill(dtEf);
            dataGridView1.DataSource = dtEf;
            con.Close();
        }
        private void btn_FiredEmp_Click(object sender, EventArgs e)
        {
            LoadFiredEmployee();
        }
    }
}
