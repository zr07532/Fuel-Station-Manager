CREATE TABLE [Products] (
	Product_ID varchar(10) NOT NULL,
	Product_Name varchar(255) NOT NULL,
	Selling_price float NOT NULL,
	Present_Quantity float NOT NULL,
  CONSTRAINT [PK_PRODUCTS] PRIMARY KEY CLUSTERED
  (
  [Product_ID] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
CREATE TABLE [Suppliers] (
	Supplier_ID varchar(10) NOT NULL,
	Supplier_Name varchar(255) NOT NULL,
	Contact_Num varchar(255) NOT NULL,
	Email_Address varchar(255) NOT NULL,
	Product_Supplied varchar(10) NOT NULL,
  CONSTRAINT [PK_SUPPLIERS] PRIMARY KEY CLUSTERED
  (
  [Supplier_ID] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
CREATE TABLE [Customer_Product] (
	Transaction_ID integer NOT NULL,
	Customer_Name varchar(255) NOT NULL,
	Product_ID varchar(10) NOT NULL,
	Booth_ID varchar(5) NOT NULL,
	Quantity_Bought float NOT NULL,
	Total_Bill float NOT NULL,
	Transaction_Date datetime NOT NULL,
	Payment_Method varchar(10) NULL,
	Card_Number varchar(19) null,
	Transaction_By integer NOT NULL,
  CONSTRAINT [PK_CUSTOMER_PRODUCT] PRIMARY KEY CLUSTERED
  (
  [Transaction_ID] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
CREATE TABLE [Supply_Schedule] (
	Supply_ID integer NOT NULL,
	Product_ID varchar(10) NOT NULL,
	Supply_Date datetime NOT NULL,
	Buying_Price float NOT NULL,
	Quantity float NOT NULL,
  CONSTRAINT [PK_SUPPLY_SCHEDULE] PRIMARY KEY CLUSTERED
  (
  [Supply_ID] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
CREATE TABLE [Booth_Detail] (
	Booth_ID varchar(5) NOT NULL,
  CONSTRAINT [PK_BOOTH_DETAIL] PRIMARY KEY CLUSTERED
  (
  [Booth_ID] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
CREATE TABLE [Booth_Products] (
	Booth_ID varchar(5) NOT NULL,
	Product_ID varchar(10) NOT NULL,
  CONSTRAINT [PK_BOOTH_PRODUCTS] PRIMARY KEY CLUSTERED
  (
  [Booth_ID] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
CREATE TABLE [Employees] (
	ID integer NOT NULL,
	First_Name varchar(255) NOT NULL,
	Last_Name varchar(255) NOT NULL,
	Hire_Date datetime NOT NULL,
	Salary integer NOT NULL,
	Email_Address varchar(255) NOT NULL,
	Contact_Number varchar(255) NOT NULL,
	IsAdmin bit,
	UserName varchar(255),
	Acc_Password varchar(255),
	Working bit,
  CONSTRAINT [PK_EMPLOYEES] PRIMARY KEY CLUSTERED
  (
  [ID] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO

ALTER TABLE [Suppliers] WITH CHECK ADD CONSTRAINT [Suppliers_fk0] FOREIGN KEY ([Product_Supplied]) REFERENCES [Products]([Product_ID])
ON UPDATE CASCADE
GO
ALTER TABLE [Suppliers] CHECK CONSTRAINT [Suppliers_fk0]
GO

ALTER TABLE [Customer_Product] WITH CHECK ADD CONSTRAINT [Customer_Product_fk0] FOREIGN KEY ([Product_ID]) REFERENCES [Products]([Product_ID])
ON UPDATE CASCADE
GO
ALTER TABLE [Customer_Product] CHECK CONSTRAINT [Customer_Product_fk0]
GO
ALTER TABLE [Customer_Product] WITH CHECK ADD CONSTRAINT [Customer_Product_fk1] FOREIGN KEY ([Booth_ID]) REFERENCES [Booth_Detail]([Booth_ID])
ON UPDATE CASCADE
GO
ALTER TABLE [Customer_Product] CHECK CONSTRAINT [Customer_Product_fk1]
GO
ALTER TABLE [Customer_Product] WITH CHECK ADD CONSTRAINT [Customer_Product_fk2] FOREIGN KEY ([Transaction_By]) REFERENCES [Employees]([ID])
ON UPDATE CASCADE
GO
ALTER TABLE [Customer_Product] CHECK CONSTRAINT [Customer_Product_fk2]
GO

ALTER TABLE [Supply_Schedule] WITH CHECK ADD CONSTRAINT [Supply_Schedule_fk0] FOREIGN KEY ([Product_ID]) REFERENCES [Products]([Product_ID])
ON UPDATE CASCADE
GO
ALTER TABLE [Supply_Schedule] CHECK CONSTRAINT [Supply_Schedule_fk0]
GO


ALTER TABLE [Booth_Products] WITH CHECK ADD CONSTRAINT [Booth_Products_fk0] FOREIGN KEY ([Booth_ID]) REFERENCES [Booth_Detail]([Booth_ID])
ON UPDATE CASCADE
GO
ALTER TABLE [Booth_Products] CHECK CONSTRAINT [Booth_Products_fk0]
GO
ALTER TABLE [Booth_Products] WITH CHECK ADD CONSTRAINT [Booth_Products_fk1] FOREIGN KEY ([Product_ID]) REFERENCES [Products]([Product_ID])
ON UPDATE CASCADE
GO
ALTER TABLE [Booth_Products] CHECK CONSTRAINT [Booth_Products_fk1]
GO